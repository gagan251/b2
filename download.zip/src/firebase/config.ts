export const firebaseConfig = {
  "projectId": "studio-5814286313-4a043",
  "appId": "1:50657845773:web:87d2bacd3e183e473b2b44",
  "apiKey": "AIzaSyClMOD0RWkHsV2Gr89MQAJrpeoYtGglvDA",
  "authDomain": "studio-5814286313-4a043.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "50657845773"
};
