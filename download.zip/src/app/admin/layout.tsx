'use client';

import { useEffect, useState } from 'react';
import { useUser, useFirestore, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { usePathname, useRouter } from 'next/navigation';
import PageLoader from '@/components/ui/page-loader';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const auth = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  const [isAdmin, setIsAdmin] = useState(false);
  const [isCheckingRole, setIsCheckingRole] = useState(true);

  const isPublicAdminPage = ['/admin/login', '/admin/signup', '/admin/forgot-password'].includes(pathname);

  /*
  // SECURITY CHECK: Temporarily disabled for client preview.
  useEffect(() => {
    if (isUserLoading) {
      return; // Wait until user state is loaded
    }

    if (isPublicAdminPage) {
        setIsCheckingRole(false);
        // if a logged-in user tries to access login page, redirect them to dashboard
        if (user) {
            router.replace('/admin/dashboard');
        }
        return;
    }

    if (!user) {
      router.replace('/admin/login');
      return;
    }

    const checkAdminRole = async () => {
      if (!firestore) return;
      const userDocRef = doc(firestore, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);
      if (userDoc.exists() && userDoc.data().role === 'admin') {
        setIsAdmin(true);
      } else {
        await signOut(auth);
        router.replace('/');
      }
      setIsCheckingRole(false);
    };

    checkAdminRole();

  }, [user, isUserLoading, firestore, router, isPublicAdminPage, pathname, auth]);

  if (isUserLoading || (!isPublicAdminPage && isCheckingRole)) {
    return <PageLoader />;
  }

  if (!isPublicAdminPage && !isAdmin) {
    return <PageLoader />;
  }
  */
  
  // IMPORTANT: The admin authorization has been temporarily disabled for client preview.
  // Ask to re-enable security before going live.
  return <>{children}</>;
}
