'use client';

import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Keyboard, Play, Pause, Clock, RefreshCw, Send } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';

// Mock data for the current test
const MOCK_TEST_DATA = {
    id: 1,
    title: 'English Dictation Practice (80 WPM)',
    speed: 80, // WPM
    duration: 2, // minutes
    audioSrc: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', // Placeholder audio
    originalText: "Four score and seven years ago our fathers brought forth on this continent, a new nation, conceived in Liberty, and dedicated to the proposition that all men are created equal."
};

export default function StenoPracticePage() {
    const { toast } = useToast();
    const audioRef = useRef<HTMLAudioElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isTestActive, setIsTestActive] = useState(false);
    const [transcription, setTranscription] = useState("");
    const [evaluationResult, setEvaluationResult] = useState<{ wpm: number; accuracy: number; } | null>(null);

    const totalDuration = MOCK_TEST_DATA.duration * 60;
    const [timeLeft, setTimeLeft] = useState(totalDuration);
    const progress = ((totalDuration - timeLeft) / totalDuration) * 100;
    
    // Timer logic
    useEffect(() => {
        if (!isTestActive || timeLeft <= 0) {
            if(timeLeft <= 0) {
                setIsPlaying(false);
                if (audioRef.current) {
                    audioRef.current.pause();
                }
                toast({ title: "Time's up!", description: "Your practice session has ended. Submit your work for evaluation." });
            }
            return;
        };

        const timerId = setInterval(() => {
            setTimeLeft(prevTime => prevTime - 1);
        }, 1000);

        return () => clearInterval(timerId);
    }, [isTestActive, timeLeft, toast]);

    const handlePlayPause = () => {
        if (!audioRef.current) return;

        if (isPlaying) {
            audioRef.current.pause();
            setIsPlaying(false);
            setIsTestActive(false);
        } else {
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
            setIsPlaying(true);
            setIsTestActive(true);
        }
    };

    const handleReset = () => {
        if(audioRef.current) {
            audioRef.current.pause();
            audioRef.current.currentTime = 0;
        }
        setIsPlaying(false);
        setIsTestActive(false);
        setTimeLeft(totalDuration);
        setTranscription("");
        setEvaluationResult(null);
    };

    const handleSubmit = () => {
        if (audioRef.current) {
            audioRef.current.pause();
        }
        setIsPlaying(false);
        setIsTestActive(false);

        const submittedText = transcription.trim();
        if (submittedText.length === 0) {
            toast({
                variant: 'destructive',
                title: 'No transcription submitted',
                description: 'Please type something before submitting.',
            });
            return;
        }

        // Simple evaluation logic
        const originalWords = MOCK_TEST_DATA.originalText.toLowerCase().replace(/[.,]/g, '').split(/\s+/);
        const submittedWords = submittedText.toLowerCase().replace(/[.,]/g, '').split(/\s+/);
        
        let correctWords = 0;
        originalWords.forEach((word, index) => {
            if (submittedWords[index] === word) {
                correctWords++;
            }
        });

        const accuracy = (correctWords / originalWords.length) * 100;

        const timeElapsedMinutes = (totalDuration - timeLeft) / 60;
        const wpm = timeElapsedMinutes > 0 ? Math.round(submittedWords.length / timeElapsedMinutes) : 0;
        
        setEvaluationResult({ wpm, accuracy });
    };

    const formatTime = (seconds: number) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    };

    return (
        <>
            <div className="space-y-6">
                <Card className="overflow-hidden">
                    <CardHeader className="bg-secondary">
                        <CardTitle className="flex items-center gap-3 text-xl">
                            <Keyboard className="h-6 w-6 text-primary" />
                            <span>Stenography Practice Test</span>
                        </CardTitle>
                        <CardDescription>
                            {MOCK_TEST_DATA.title}
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                        <div className="p-4 border rounded-lg bg-card/50">
                            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                                <div className="flex items-center gap-4">
                                    <Button onClick={handlePlayPause} size="icon" className="h-12 w-12 rounded-full">
                                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                                    </Button>
                                    <div>
                                        <h3 className="font-semibold">Dictation Audio</h3>
                                        <p className="text-sm text-muted-foreground">Press play to begin the test.</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 text-lg font-medium tabular-nums text-primary">
                                    <Clock className="h-5 w-5" />
                                    <span>{formatTime(timeLeft)}</span>
                                </div>
                            </div>
                            <Progress value={progress} className="mt-4 h-2" />
                            <audio ref={audioRef} src={MOCK_TEST_DATA.audioSrc} onEnded={() => {
                                setIsPlaying(false);
                                setIsTestActive(false);
                            }} />
                        </div>

                        <div>
                            <h3 className="text-lg font-semibold mb-2">Transcription Pad</h3>
                            <Textarea
                                placeholder="Start typing your transcription here as you listen to the audio..."
                                className={cn(
                                    "min-h-[300px] text-base",
                                    // Use this class to apply the Kruti Dev font
                                    "font-krutidev" 
                                )}
                                value={transcription}
                                onChange={(e) => setTranscription(e.target.value)}
                                disabled={!isTestActive && transcription.length > 0 && timeLeft > 0}
                            />
                        </div>

                    </CardContent>
                    <CardFooter className="bg-secondary/50 p-6 flex justify-between">
                        <Button variant="outline" onClick={handleReset}>
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Reset Test
                        </Button>
                        <Button onClick={handleSubmit} disabled={transcription.length === 0}>
                            <Send className="mr-2 h-4 w-4" />
                            Submit for Evaluation
                        </Button>
                    </CardFooter>
                </Card>
            </div>
            <AlertDialog open={!!evaluationResult} onOpenChange={() => setEvaluationResult(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Evaluation Result</AlertDialogTitle>
                        <AlertDialogDescription>
                            Here is the analysis of your transcription practice.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="my-4 grid grid-cols-2 gap-4 text-center">
                        <div>
                            <p className="text-sm text-muted-foreground">Typing Speed</p>
                            <p className="text-3xl font-bold">{evaluationResult?.wpm} <span className="text-lg font-normal">WPM</span></p>
                        </div>
                        <div>
                            <p className="text-sm text-muted-foreground">Accuracy</p>
                            <p className="text-3xl font-bold">{evaluationResult?.accuracy.toFixed(1)}<span className="text-lg font-normal">%</span></p>
                        </div>
                    </div>
                    <AlertDialogFooter>
                        <AlertDialogAction onClick={() => { setEvaluationResult(null); handleReset(); }}>Try Again</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}
