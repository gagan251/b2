'use client';

import { SiteLogo } from '../site-logo';

const PageLoader = () => {
  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm transition-opacity duration-300">
        <div className="relative flex h-28 w-28 items-center justify-center">
            <div className="absolute h-full w-full rounded-full border-t-4 border-b-4 border-primary animate-spin"></div>
            <SiteLogo />
        </div>
        <p className="mt-4 text-center text-muted-foreground animate-pulse">
            Getting things ready...
        </p>
    </div>
  );
};

export default PageLoader;
